import java.util.Arrays;

import org.apache.thrift.TBase;
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TMemoryBuffer;

/**
 *
 * thrift对象序列化工具
 * @author <a href="mailto:chong.sun@renren-inc.com">sun chong</a>
 * @version 2012-12-10
 */
public class ThriftSerialize {
	/**
	 * 将对象序列化成二进制
	 * @param base
	 * @return
	 */
	public static byte[] serialize(TBase<?, ?> base){
		if(base == null){
			return null;
		}
		TMemoryBuffer buffer = new TMemoryBuffer(64);
		TProtocol protocol = new TCompactProtocol(buffer);
		try {
			base.write(protocol);
			byte[] bytes = new byte[buffer.length()];
			buffer.read(bytes, 0, bytes.length);
			return bytes;
		} catch (TException e) {
			throw new RuntimeException("thrift serialize error. base=" + base);
		}
	}
	
	public static void deSerialize(TBase<?, ?> base, byte[] bytes){
		if(base == null || bytes == null){
			return;
		}
		TMemoryBuffer buffer = new TMemoryBuffer(64);
		TProtocol protocol = new TCompactProtocol(buffer);
		try {
			buffer.write(bytes);
			base.read(protocol);
		} catch (TException e) {
			throw new RuntimeException("thrift deSerialize error. base=" + base + " bytes=" + Arrays.toString(bytes));
		} 
	}
}
